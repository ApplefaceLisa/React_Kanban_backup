module.exports = {
	connectString: 'mongodb://localhost/kanbanapi'
};